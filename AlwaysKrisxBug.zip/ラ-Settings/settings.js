const fs = require('fs')
const chalk = require('chalk')

global.ytname = "YT: AlwaysKris"
global.location = "Indonesia"
global.ownernumber = '088294276026'  //creator number
global.botname = 'AlwaysKris X Bug' //name of the bot
global.packname = 'Sticker By'
global.author = 'AlwaysKris'
global.themeemoji = '🪀'
global.wm = "웃 AlwaysKris"
global.link = 'https://whatsapp.com/'
global.prefa = ['','!','.','#','&']

global.domain = 'https://pt-yudamods.xin.web.id/' // Isi Domain Lu
global.apikey = 'ptla_PyLWDVKX6Pi8YNtaOjG4aSvay4OQwoFiVEMG3MdIqLj' // Isi Apikey Plta Lu
global.capikey = 'ptlc_5zBeIOVf8hREwezODYdyxkUzDAPgxSi94GxIvYxmsTD' // Isi Apikey Pltc Lu
global.eggsnya = '5' // id eggs yang dipakai
global.location = '1' // id location

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})